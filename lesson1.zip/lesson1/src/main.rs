extern crate sdl2;

use sdl2::pixels::Color;
use sdl2::event::Event;

const WIDTH:  u32 = 640;
const HEIGHT: u32 = 480;

fn main() -> Result<(), String> {
    // First, we initialize SDL Context, so we can get access to all subsystems, like video or audio.
    // To keep error handling simple, and not leave "unwraps" everyone, we gonna use "?" syntax
    // This syntax allows us to return error type from the function in case something goes wrong.
    // The main diffrence between ? and unwrap is that ? does not panic when error is occurring.
    // But these syntax is allowed to use only in fuctions, which has return type of Result in their signature.
    let sdl_context = sdl2::init()?;

    // So now, when SDL is initialized, we can create a VideoSubsystem, that can work with graphics on the screen.
    // Here we are also using ? syntax.
    let video = sdl_context.video().map_err(|e| e.to_string())?;

    // Okay, so now we have an initialized SDL and Videosubsystem, and with this, we can create a window that will be displayed on screen.
    let window = video.window("SDL Tutorial 1", WIDTH, HEIGHT)
        .position_centered()
        .opengl()
        .build().map_err(|e| e.to_string())?;

    // From that point you may see some differences from other tutorials on these topics.
    // Since renderer has been deleted from sdl2 crate api, we gonna create canvas, which is the same.
    let mut canvas = window
        .into_canvas()
        .present_vsync()
        .build().map_err(|e| e.to_string())?;
        

    // And here comes the main diffrence from other tutorial - now we will create an event_pump, that will represent a stream of events, that are happening in our application.
    // What we actualy gonna do, is to create a loop, which will have an inner loop, that will iterate over events, and check if the exit event is occured, and when events are checked,
    // we will run some code, that will fill our window with just black color.
    let mut event_pump = sdl_context.event_pump().map_err(|e| e.to_string())?;

    // Don't worry, this ' syntax is not a lifetime, it is an awesome feature of the rust, called label. We can label a loop, so we can break an outer loop from the inner loop with the "break" keyword, instead of
    // breaking the inner loop first, and then breaking the outer loop
    // In the inner loop, we iterate over list of events, and if some event is exit (that stands for pressing X in the programm window), than our loop will break outer loop, which will cause our function
    // to return Ok type and finish the programm
    'running: loop {
        for event in event_pump.poll_iter() {
            match event {
                Event::Quit { .. } => break 'running,
                _ => {}
            }
        }
        // And here comes the most interesting part - first, we set the draw color of canvas to black, then we clear the canvas, and then canvas fills the sceen with color, that we gave him.
        canvas.set_draw_color(Color::RGB(0,0,0));
        canvas.clear();
        canvas.present();
    }
    Ok(())
}